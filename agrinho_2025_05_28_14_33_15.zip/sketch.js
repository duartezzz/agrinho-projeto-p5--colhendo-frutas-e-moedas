let player;
let frutas = [];
let moedas = [];
let score = 0;

function setup() {
  createCanvas(800, 400);
  player = new Player();

  // Criar frutas no campo (lado esquerdo)
  for (let i = 0; i < 5; i++) {
    frutas.push(new Item(random(20, width/2 - 20), random(height - 150, height - 50), 'fruit'));
  }

  // Criar moedas na cidade (lado direito)
  for (let i = 0; i < 5; i++) {
    moedas.push(new Item(random(width/2 + 20, width - 20), random(height - 150, height - 50), 'coin'));
  }

  noStroke();
}

function draw() {
  background(135, 206, 235); // céu azul

  drawCampo(0, 0, width/2, height);
  drawCidade(width/2, 0, width/2, height);

  player.update();
  player.show();

  // Mostrar e checar frutas
  for (let i = frutas.length - 1; i >= 0; i--) {
    frutas[i].show();
    if (player.collects(frutas[i])) {
      frutas.splice(i, 1);
      score += 1;
    }
  }

  // Mostrar e checar moedas
  for (let i = moedas.length - 1; i >= 0; i--) {
    moedas[i].show();
    if (player.collects(moedas[i])) {
      moedas.splice(i, 1);
      score += 2;
    }
  }

  // Placar
  fill(0);
  textSize(24);
  text("Pontuação: " + score, 10, 30);

  // Mensagem de fim
  if (frutas.length === 0 && moedas.length === 0) {
    textSize(32);
    fill('darkgreen');
    textAlign(CENTER);
    text("Parabéns! Você coletou tudo!", width/2, height/2);
    noLoop();
  }
}

// Classes e funções

class Player {
  constructor() {
    this.x = width/4;
    this.y = height - 60;
    this.size = 30;
    this.speed = 4;
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }
    // Limitar dentro do canvas
    this.x = constrain(this.x, 0 + this.size/2, width - this.size/2);
    this.y = constrain(this.y, 0 + this.size/2, height - this.size/2);
  }

  show() {
    fill(0, 0, 255);
    ellipse(this.x, this.y, this.size);
  }

  collects(item) {
    let d = dist(this.x, this.y, item.x, item.y);
    return d < (this.size/2 + item.size/2);
  }
}

class Item {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.type = type; // 'fruit' ou 'coin'
    this.size = 20;
  }

  show() {
    if (this.type === 'fruit') {
      fill('red');
      ellipse(this.x, this.y, this.size);
      fill('green');
      rect(this.x - 5, this.y - 15, 10, 5); // galho simples
    } else if (this.type === 'coin') {
      fill('yellow');
      ellipse(this.x, this.y, this.size);
      fill(255, 215, 0);
      textSize(14);
      textAlign(CENTER, CENTER);
      text("$", this.x, this.y);
    }
  }
}

function drawCampo(x, y, w, h) {
  push();
  translate(x, y);

  // Sol
  fill(255, 204, 0);
  ellipse(100, 100, 80);

  // Colinas
  fill(34, 139, 34);
  ellipse(w * 0.3, h, w * 0.8, h);
  ellipse(w * 0.7, h, w * 0.8, h);

  // Árvores
  for (let i = 0; i < 5; i++) {
    let tx = map(i, 0, 4, 50, w - 50);
    drawArvore(tx, h - 80);
  }

  pop();
}

function drawCidade(x, y, w, h) {
  push();
  translate(x, y);

  // Solo
  fill(100);
  rect(0, h - 100, w, 100);

  // Prédios
  for (let i = 0; i < 5; i++) {
    let bw = 40;
    let bh = 100 + i * 10;
    let bx = i * (w / 5) + 10;
    fill(50);
    rect(bx, h - 100 - bh, bw, bh);

    // Janelas
    fill(255, 255, 100);
    for (let j = 0; j < 4; j++) {
      rect(bx + 10, h - 100 - bh + j * 20 + 10, 10, 10);
    }
  }

  pop();
}

function drawArvore(x, y) {
  // Tronco
  fill(101, 67, 33);
  rect(x - 5, y, 10, 30);

  // Folhas
  fill(34, 139, 34);
  ellipse(x, y, 40, 40);
}
